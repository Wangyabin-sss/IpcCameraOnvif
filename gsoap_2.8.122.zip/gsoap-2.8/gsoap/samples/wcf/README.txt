
INSTRUCTIONS

Install the WCF samples.

For the basic bindings, you should have:

  C:\WF_WCF_Samples\WCF\Basic\Binding\Basic\Http
  C:\WF_WCF_Samples\WCF\Basic\Binding\Basic\TransportSecurity
  C:\WF_WCF_Samples\WCF\Basic\Binding\Basic\MessageSecurity

The gSOAP examples to interact with the WCF client and service examples:

  Basic/Http
  Basic/TransportSecurity
  Basic/MessageSecurity

For the WS bindings, you should have:

  C:\WF_WCF_Samples\WCF\Basic\Binding\WS\DualHttp

The gSOAP examples to interact with the WCF client and service examples:

  WS/DualHttp

Additional sample demo applications for WCF bindings will be added to upcoming
gSOAP releases.

